/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuroraState } from './types';
import { Navbar } from './components/Navbar';
import { LabView } from './components/LabView';
import { WorkView } from './components/WorkView';
import { WalletView } from './components/WalletView';
import { TradingView } from './components/TradingView';
import { TreasuryVaultView } from './components/TreasuryVaultView';
import { InstructionsView } from './components/InstructionsView';
import KillSwitchView from './components/KillSwitchView';
import AuroraControlPanel from './components/AuroraControlPanel';
import { Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'lab' | 'work' | 'wallet' | 'trading' | 'treasury' | 'instructions' | 'killswitch' | 'control'>('lab');
  const [state, setState] = useState<AuroraState | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchState = async () => {
    try {
      const res = await fetch('/api/aurora/state');
      const data = await res.json();
      setState(data);
    } catch (err) {
      console.error("Failed to fetch Aurora state", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 10000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !state) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-cyan-400 gap-4">
        <div className="relative">
          <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 blur-md opacity-75 animate-pulse"></div>
          <div className="relative w-16 h-16 rounded-2xl bg-slate-900 border border-cyan-400/50 flex items-center justify-center">
            <Sparkles className="w-8 h-8 animate-spin" />
          </div>
        </div>
        <p className="font-mono text-sm tracking-wider animate-pulse">
          INIZIALIZZAZIONE LABORATORIO AURORA LUXURY INFINITI...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      
      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: string) => setActiveTab(tab as any)}
        balance={state.balance}
        status={state.status}
      />

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-8">
        {activeTab === 'lab' && <LabView state={state} refreshState={fetchState} />}
        {activeTab === 'work' && <WorkView state={state} onTasksUpdated={fetchState} />}
        {activeTab === 'wallet' && <WalletView state={state} onTransferCompleted={fetchState} />}
        {activeTab === 'trading' && <TradingView state={state} refreshState={fetchState} />}
        {activeTab === 'treasury' && <TreasuryVaultView state={state} refreshState={fetchState} />}
        {activeTab === 'instructions' && <InstructionsView />}
        {activeTab === 'killswitch' && <KillSwitchView />}
        {activeTab === 'control' && <AuroraControlPanel />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-4 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 Aurora Luxury Infiniti • Laboratorio IT Autonomo & Sistema Finanziario</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Tutti i sistemi operativi a regime quantistico</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

