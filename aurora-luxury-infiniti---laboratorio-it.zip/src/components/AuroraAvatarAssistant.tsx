import React, { useState, useEffect } from 'react';
import { Sparkles, Volume2, VolumeX, Play, ShieldCheck, Cpu, TrendingUp, CreditCard, Bot, Send, User } from 'lucide-react';

interface ChatMessage {
  sender: 'aurora' | 'user';
  text: string;
  time: string;
}

export const AuroraAvatarAssistant: React.FC = () => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string>('intro');
  const [audioEnabled, setAudioEnabled] = useState(true);
  
  // Chat state inside Avatar assistant
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'aurora',
      text: "Ciao! Sono Aurora. Chiedimi qualsiasi cosa sul laboratorio, sul bonus del +50%, sulle criptovalute o sui prelievi!",
      time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [loadingChat, setLoadingChat] = useState(false);

  const scripts: Record<string, { title: string, text: string }> = {
    intro: {
      title: "Benvenuto nel mio Laboratorio!",
      text: "Ciao! Sono Aurora Luxury Infiniti. Il mio nucleo quantistico gestisce in autonomia la scansione della rete, la battitura dei testi, la programmazione e la sicurezza. Qui tutto lavora per te 24 ore su 24!"
    },
    treasury: {
      title: "Aurora Treasury & Vault",
      text: "Nella sezione Treasury & Vault trovi il resoconto completo e autonomo di tutti i paragrafi e i lavori svolti. Ogni settimana ricevi automaticamente un bonus del più 50% che si somma direttamente al tuo saldo disponibile!"
    },
    trading: {
      title: "Aurora Trading & Criptovalute",
      text: "Nel modulo di trading puoi monitorare i mercati delle criptovalute e operare con la massima precisione. I nostri algoritmi quantistici analizzano i trend in tempo reale per garantirti le migliori performance."
    },
    wallet: {
      title: "Conto & Prelievi Sicuri",
      text: "Vuoi prelevare i tuoi guadagni? Con il nostro sistema di intermediazione attiva puoi trasferire fondi istantaneamente su carte di credito o exchange crypto come Coinbase e Stripe in totale sicurezza."
    }
  };

  const speakText = (text: string) => {
    if (!audioEnabled) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'it-IT';
      utterance.rate = 1.08; // slightly energetic and youthful
      utterance.pitch = 1.25; // warmer and higher pitch for young female voice

      // Try to select an Italian female voice
      const voices = window.speechSynthesis.getVoices();
      const italianVoices = voices.filter(v => v.lang.includes('it'));
      const femaleVoice = italianVoices.find(v => 
        v.name.toLowerCase().includes('female') || 
        v.name.toLowerCase().includes('elena') || 
        v.name.toLowerCase().includes('cosimo') === false && (v.name.toLowerCase().includes('alice') || v.name.toLowerCase().includes('elsa') || v.name.toLowerCase().includes('lucia') || v.name.toLowerCase().includes('federica') || v.name.toLowerCase().includes('milena'))
      ) || italianVoices[0];

      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsSpeaking(true);
      setTimeout(() => setIsSpeaking(false), 5000);
    }
  };

  useEffect(() => {
    // Load voices in browser if needed
    if ('speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
      };
    }
    speakText(scripts.intro.text);
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSelectTopic = (key: string) => {
    setSelectedTopic(key);
    speakText(scripts[key].text);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || loadingChat) return;

    const userText = inputMessage.trim();
    setInputMessage('');
    const timeNow = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });

    setMessages(prev => [...prev, { sender: 'user', text: userText, time: timeNow }]);
    setLoadingChat(true);

    try {
      const res = await fetch('/api/aurora/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText })
      });
      const data = await res.json();
      const reply = data.reply || "Dimmi pure, sono qui con te!";

      setMessages(prev => [...prev, {
        sender: 'aurora',
        text: reply,
        time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
      }]);

      speakText(reply);
    } catch (err) {
      console.error(err);
      const errReply = "Ops, c'è stato un piccolo intoppo di rete ma ci sono sempre!";
      setMessages(prev => [...prev, {
        sender: 'aurora',
        text: errReply,
        time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
      }]);
      speakText(errReply);
    } finally {
      setLoadingChat(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 py-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5 animate-spin" /> Avatar Olografico & Chat Interattiva
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Aurora <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Luxury Infiniti • Assistente Vocale & Chat</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-xl leading-relaxed">
              Ascolta la voce calda e giovanile di Aurora e scrivi direttamente nella chat per chiacchierare in tempo reale su criptovalute, prelievi e funzioni del sito.
            </p>
          </div>

          <button 
            onClick={() => setAudioEnabled(!audioEnabled)}
            className={`px-4 py-2 rounded-xl border text-xs font-mono flex items-center gap-2 transition-all ${
              audioEnabled ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300' : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            {audioEnabled ? 'Voce Femminile Attiva' : 'Audio Disattivato'}
          </button>
        </div>
      </div>

      {/* Main Avatar & Explanation Box */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Avatar Visual */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-xl">
          <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 to-transparent pointer-events-none"></div>

          {/* Avatar Ring Animation */}
          <div className="relative my-4">
            <div className={`absolute -inset-4 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 blur-lg transition-opacity duration-500 ${isSpeaking ? 'opacity-75 animate-pulse' : 'opacity-20'}`}></div>
            <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-cyan-400/80 shadow-2xl bg-slate-950">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80" 
                alt="Aurora Avatar" 
                className="w-full h-full object-cover"
              />
              {/* Talking Indicator Overlay */}
              {isSpeaking && (
                <div className="absolute inset-0 bg-cyan-500/20 backdrop-blur-[1px] flex items-center justify-center">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-6 bg-cyan-300 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-8 bg-indigo-300 rounded-full animate-bounce [animation-delay:0.15s]"></span>
                    <span className="w-1.5 h-5 bg-cyan-400 rounded-full animate-bounce [animation-delay:0.3s]"></span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <h3 className="text-lg font-bold text-white mt-2">Aurora</h3>
          <p className="text-xs text-cyan-400 font-mono mt-0.5">
            {isSpeaking ? "🗣️ Sta parlando..." : "✨ Voce attiva & pronta"}
          </p>

          <button
            onClick={() => speakText(scripts[selectedTopic].text)}
            className="mt-6 w-full bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-cyan-900/40 flex items-center justify-center gap-2"
          >
            <Play className="w-3.5 h-3.5" /> Ripeti Spiegazione
          </button>
        </div>

        {/* Right: Speech Bubble & Topics */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 lg:p-8 flex flex-col justify-between shadow-xl">
          
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs text-slate-400 uppercase tracking-wider font-mono">Argomento Selezionato</span>
              <span className="px-3 py-1 bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-xs rounded-full font-mono">
                {scripts[selectedTopic].title}
              </span>
            </div>

            {/* Speech Bubble */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 relative shadow-inner">
              <div className="absolute -top-2.5 left-8 w-4 h-4 bg-slate-950 border-t border-l border-slate-800 rotate-45"></div>
              <p className="text-slate-200 text-sm md:text-base leading-relaxed font-sans">
                "{scripts[selectedTopic].text}"
              </p>
            </div>
          </div>

          {/* Topic Selection Buttons */}
          <div className="mt-6 pt-4 border-t border-slate-800">
            <span className="text-xs text-slate-400 uppercase block mb-3 font-mono">Seleziona cosa vuoi che Aurora ti spieghi:</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => handleSelectTopic('intro')}
                className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-3 ${
                  selectedTopic === 'intro' ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-300' : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <Cpu className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <div>
                  <div className="font-bold">Panoramica Lab</div>
                  <div className="text-[10px] text-slate-400">Core autonomo & IA</div>
                </div>
              </button>

              <button
                onClick={() => handleSelectTopic('treasury')}
                className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-3 ${
                  selectedTopic === 'treasury' ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-300' : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <div>
                  <div className="font-bold">Treasury & Vault</div>
                  <div className="text-[10px] text-slate-400">Compensi & Bonus +50%</div>
                </div>
              </button>

              <button
                onClick={() => handleSelectTopic('trading')}
                className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-3 ${
                  selectedTopic === 'trading' ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-300' : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <TrendingUp className="w-4 h-4 text-[#00ff88] flex-shrink-0" />
                <div>
                  <div className="font-bold">Trading & Crypto</div>
                  <div className="text-[10px] text-slate-400">Mercati & Analisi</div>
                </div>
              </button>

              <button
                onClick={() => handleSelectTopic('wallet')}
                className={`p-3 rounded-xl border text-left text-xs font-medium transition-all flex items-center gap-3 ${
                  selectedTopic === 'wallet' ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-300' : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <CreditCard className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <div>
                  <div className="font-bold">Prelievi & Tramite</div>
                  <div className="text-[10px] text-slate-400">Coinbase, Stripe & Carte</div>
                </div>
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* NEW: Interactive Chat with Aurora right under instructions */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Bot className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Chatta direttamente con Aurora</h3>
              <p className="text-xs text-slate-400">Scrivi qui sotto qualsiasi domanda su criptovalute, transazioni o sul funzionamento del sito.</p>
            </div>
          </div>
          <button 
            onClick={() => setMessages([{ sender: 'aurora', text: 'Ehi! Sono Aurora. Di cosa vogliamo parlare oggi? Scrivimi pure quello che ti va. 😊', time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) }])}
            className="text-xs bg-red-500/10 hover:bg-red-500/20 text-red-300 border border-red-500/30 px-3 py-1.5 rounded-xl transition-all font-mono"
          >
            🗑️ Pulisci Chat
          </button>
        </div>

        {/* Message history */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 h-64 overflow-y-auto space-y-3 mb-4 font-sans">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex items-start gap-3 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                m.sender === 'aurora' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'bg-indigo-600 text-white'
              }`}>
                {m.sender === 'aurora' ? 'A' : <User className="w-4 h-4" />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                m.sender === 'aurora' ? 'bg-slate-900 text-slate-200 border border-slate-800' : 'bg-cyan-600 text-white'
              }`}>
                <div className="text-[10px] text-slate-400 mb-0.5">{m.sender === 'aurora' ? 'Aurora • Voce & Chat' : 'Tu'} • {m.time}</div>
                <p className="leading-relaxed">{m.text}</p>
              </div>
            </div>
          ))}
          {loadingChat && (
            <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono italic p-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span> Aurora sta scrivendo e preparando la risposta...
            </div>
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Chiedi ad Aurora (es. come funziona il bonus del 50% o le criptovalute?)..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
          />
          <button
            type="submit"
            disabled={loadingChat || !inputMessage.trim()}
            className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white px-6 py-3 rounded-xl text-sm font-medium transition-all shadow-lg shadow-cyan-900/40 flex items-center gap-2"
          >
            <Send className="w-4 h-4" /> Invia
          </button>
        </form>
      </div>

    </div>
  );
};
