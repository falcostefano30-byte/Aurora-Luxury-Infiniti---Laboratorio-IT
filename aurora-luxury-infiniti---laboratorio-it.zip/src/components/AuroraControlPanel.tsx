import React, { useState, useEffect, useRef } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Bot, ShieldAlert, Send, Sparkles, Terminal } from 'lucide-react';

export default function AuroraControlPanel() {
  // Stati per la Chat
  const [messages, setMessages] = useState([
    { sender: 'aurora', text: 'Ehi! Sono Aurora. Di cosa vogliamo parlare oggi? Scrivimi pure quello che ti va. 😊' }
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);

  // Stati per il Timer di Sicurezza (Kill Switch)
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minuti
  const [isActive, setIsActive] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [destroyed, setDestroyed] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // 2. Logica del Timer di Emergenza (Kill Switch)
  useEffect(() => {
    let timer: any = null;
    if (isActive && timeLeft > 0 && !destroyed) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && !destroyed) {
      setDestroyed(true);
      localStorage.clear();
      sessionStorage.clear();
    }
    return () => clearInterval(timer);
  }, [isActive, timeLeft, destroyed]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Attivazione Timer con il comando "one" o pulsante verde
  const handleStartTimer = () => {
    if (window.confirm("⚠️ ATTENZIONE: Stai per avviare il protocollo di emergenza definitivo. Confermi?")) {
      setIsActive(true);
      setTimeLeft(1800);
    }
  };

  // Disattivazione Timer con il codice "karnak089" (pulsante rosso)
  const handleDisarm = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim() === 'karnak089') {
      setIsActive(false);
      setDestroyed(false);
      setTimeLeft(1800);
      setPasscode('');
      setErrorMsg('');
      alert('✅ Sistema disarmato con successo. Tutti i dati sono protetti.');
    } else {
      setErrorMsg('❌ Codice di sblocco errato!');
    }
  };

  // 3. Gestione invio messaggi e reindirizzamento al SITO REALE per i prelievi
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || loading) return;

    const userMsg = inputText.trim();
    setInputText('');
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const userMsgLower = userMsg.toLowerCase();

      // CONTROLLO PRELIEVO / TRASFERIMENTO -> REINDIRIZZAMENTO AL SITO REALE
      if (userMsgLower.includes("preleva") || userMsgLower.includes("prelevare") || userMsgLower.includes("trasferisci") || userMsgLower.includes("soldi")) {
        setMessages(prev => [
          ...prev, 
          { sender: 'aurora', text: 'Certamente! Ti sto reindirizzando immediatamente al portale ufficiale e sicuro per elaborare il prelievo e scalare i fondi dal conto.' }
        ]);
        
        // Reindirizzamento reale dopo 2 secondi
        setTimeout(() => {
          window.location.href = "https://www.intesasanpaolo.com";
        }, 2000);
        
        setLoading(false);
        return;
      }

      // Risposta tramite API server-side
      const res = await fetch('/api/aurora/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg })
      });
      const data = await res.json();
      const replyText = data.reply || "Dimmi pure, sono qui con te!";
      setMessages(prev => [...prev, { sender: 'aurora', text: replyText }]);

    } catch (error) {
      console.error("Errore di comunicazione:", error);
      setMessages(prev => [...prev, { sender: 'aurora', text: 'Ops, c\'è stato un piccolo problema di connessione. Riprova subito!' }]);
    } finally {
      setLoading(false);
    }
  };

  const totalTime = 1800;
  const elapsed = totalTime - timeLeft;
  const chartData = [
    { name: 'Trascorso', value: elapsed },
    { name: 'Rimanente', value: timeLeft }
  ];
  const COLORS = ['#ef4444', '#164e63'];

  if (destroyed) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-black text-red-600 p-8 font-mono">
        <h1 className="text-5xl font-black mb-4 text-red-500">🛑 PROTOCOLLO COMPLETATO</h1>
        <p className="text-lg text-gray-300">Tempo scaduto. I dati locali sono stati eliminati permanentemente.</p>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col h-full bg-[#0b1329] text-white p-6 rounded-3xl border border-cyan-500/30 overflow-hidden shadow-2xl max-w-5xl mx-auto my-4">
      
      {/* Sfumatura rossa d'emergenza quando il timer è attivo */}
      {isActive && (
        <div className="absolute inset-0 bg-red-950/40 animate-pulse opacity-55 pointer-events-none"></div>
      )}

      {/* Sezione Superiore: Kill Switch (Emergenza) */}
      <div className="mb-6 p-6 bg-black/40 rounded-2xl border border-red-500/30 flex flex-col items-center">
        <h2 className="text-lg font-bold text-red-400 mb-1 flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-red-500" /> Kill Switch / Emergency Control Panel
        </h2>
        
        {/* Didascalia obbligatoria */}
        <p className="text-xs text-amber-300/90 bg-amber-950/40 border border-amber-500/30 p-3 rounded-xl text-center max-w-xl mb-4 leading-relaxed">
          ⚠️ <strong>Avviso:</strong> Usa questa funzione come <strong>ultima risorsa</strong>. Fai attenzione perché una volta scaduto il tempo il processo <strong>non è reversibile</strong>.
        </p>

        {/* Timer e Grafico */}
        <div className="relative w-full flex justify-center items-center h-36 mb-4">
          <div className="absolute inset-0 flex justify-center items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={chartData} cx="50%" cy="50%" startAngle={90} endAngle={-270} innerRadius="70%" outerRadius="90%" dataKey="value">
                  {chartData.map((_, index) => <Cell key={index} fill={COLORS[index]} stroke="none" />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className={`absolute text-center ${isActive ? 'text-red-500 animate-pulse' : 'text-gray-400'}`}>
            <div className="text-4xl font-extrabold font-mono tracking-wider">{formatTime(timeLeft)}</div>
            <div className="text-[10px] uppercase font-mono tracking-widest opacity-70">Conto alla rovescia</div>
          </div>
        </div>

        {/* I due quadratini (Verde e Rosso) */}
        <div className="flex gap-6 mb-4">
          <div className="flex flex-col items-center">
            <button onClick={handleStartTimer} disabled={isActive} className="w-14 h-14 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 rounded-2xl flex items-center justify-center shadow-lg transition-all cursor-pointer border border-emerald-400/40">
              <span className="text-2xl">🟢</span>
            </button>
            <span className="text-[11px] text-emerald-300 mt-1.5 font-medium">Attiva (One)</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg border border-red-400/40">
              <span className="text-2xl">🔴</span>
            </div>
            <span className="text-[11px] text-red-300 mt-1.5 font-medium">Blocca (Karnak)</span>
          </div>
        </div>

        {/* Form di sblocco con codice */}
        {isActive && (
          <form onSubmit={handleDisarm} className="flex gap-2 w-full max-w-md mt-2">
            <input 
              type="password"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              placeholder="Codice (karnak089)..."
              className="flex-1 bg-[#070e20] border border-red-500/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
            />
            <button type="submit" className="bg-red-600 hover:bg-red-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs shadow-lg">
              Sblocca
            </button>
          </form>
        )}
        {errorMsg && <p className="text-xs text-red-400 mt-2 font-medium">{errorMsg}</p>}
      </div>

      {/* Sezione Inferiore: Chat con Aurora e Reindirizzamento al Sito Reale */}
      <div className="flex-1 flex flex-col bg-[#070e20] rounded-2xl border border-cyan-500/20 p-5 min-h-[350px]">
        <div className="flex items-center gap-3 border-b border-cyan-500/20 pb-3 mb-4">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Bot className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Aurora AI Control Hub & Chat</h3>
            <p className="text-[11px] text-slate-400">Parla con Aurora o richiedi un prelievo/trasferimento</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2 mb-4 max-h-[300px]">
          {messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                msg.sender === 'user' ? 'bg-cyan-600 text-white' : 'bg-[#132047] border border-cyan-500/30 text-cyan-100'
              }`}>
                <p className="font-semibold opacity-70 mb-1">{msg.sender === 'user' ? 'Tu' : 'Aurora • IA Ufficiale'}</p>
                <p>{msg.text}</p>
              </div>
            </div>
          ))}
          {loading && <div className="text-xs text-cyan-300 animate-pulse">Aurora sta elaborando la risposta...</div>}
        </div>

        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input 
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Scrivi ad Aurora (es. voglio prelevare, come funziona il conto?)..."
            className="flex-1 bg-[#0b1329] border border-cyan-500/30 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-cyan-500"
          />
          <button type="submit" disabled={loading} className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-3 rounded-xl text-xs font-bold disabled:opacity-50 transition-all flex items-center gap-2">
            <Send className="w-3.5 h-3.5" /> Invia
          </button>
        </form>
      </div>

    </div>
  );
}
