import React, { useState } from 'react';
import { Terminal, Send, Sparkles, Bot, User, Trash2 } from 'lucide-react';

// Funzione sicura richiesta per inviare messaggi ad Aurora
async function inviaMessaggioSicuro(testoUtente: string): Promise<string> {
    try {
        if (!testoUtente.trim()) return "";

        const response = await fetch('/api/aurora/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: testoUtente })
        });
        const data = await response.json();
        return data.reply || "Dimmi pure, sono qui!";

    } catch (error) {
        console.error("Errore di comunicazione con Aurora:", error);
        return "Mi dispiace, si è verificato un piccolo intoppo di rete. Riprova tra un istante.";
    }
}

interface ChatMessage {
  sender: 'aurora' | 'user';
  text: string;
  time: string;
}

export const ChatView: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleClear = () => {
    setMessages([]);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    const timeNow = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });

    setMessages(prev => [...prev, { sender: 'user', text: userMsg, time: timeNow }]);
    setLoading(true);

    try {
      const replyText = await inviaMessaggioSicuro(userMsg);
      
      setMessages(prev => [...prev, {
        sender: 'aurora',
        text: replyText,
        time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
      }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        sender: 'aurora',
        text: "Ops, c'è stato un piccolo intoppo di connessione ma ci sono!",
        time: new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" /> Canale Neurale Diretto
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Chat con <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Aurora AI</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Comunica in tempo reale con Aurora Luxury Infiniti. Chiacchiera, fai domande o chiedi qualsiasi cosa con un linguaggio naturale e umano.
            </p>
          </div>
        </div>
      </div>

      {/* Chat Box */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl shadow-xl flex flex-col h-[550px] overflow-hidden">
        
        {/* Chat Header */}
        <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-cyan-400 shadow-md">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80" 
                alt="Aurora" 
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Aurora</h3>
              <p className="text-[11px] text-emerald-400 font-mono flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Online • Pronta a chiacchierare
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleClear}
              className="px-3 py-1 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-mono flex items-center gap-1.5 transition-all"
              title="Pulisci cronologia chat"
            >
              <Trash2 className="w-3.5 h-3.5" /> Pulisci Chat
            </button>
          </div>
        </div>

        {/* Message History */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-950/40">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-3">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-cyan-500 shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80" 
                  alt="Aurora" 
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-sm">Ehi! Sono Aurora. Di cosa vogliamo parlare oggi? Scrivimi pure quello che ti va. 😊</p>
            </div>
          )}

          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex items-start gap-3 max-w-2xl ${
                msg.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
              }`}
            >
              {msg.sender === 'user' ? (
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white flex items-center justify-center shrink-0 shadow-lg">
                  <User className="w-4 h-4" />
                </div>
              ) : (
                <div className="w-8 h-8 rounded-full overflow-hidden border border-cyan-400 shrink-0 shadow-md">
                  <img 
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" 
                    alt="Aurora" 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className={`space-y-1 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-none shadow-lg'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none shadow-md'
                }`}>
                  {msg.text}
                </div>
                <div className="text-[10px] text-slate-500 font-mono px-1">
                  {msg.time}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3 mr-auto">
              <div className="w-8 h-8 rounded-full overflow-hidden border border-cyan-400 shrink-0">
                <img 
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" 
                  alt="Aurora" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-mono">
                Aurora sta scrivendo...
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Scrivi un messaggio ad Aurora..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-5 py-3 text-sm text-white focus:outline-none focus:border-cyan-500 transition-all font-mono"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className={`px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center gap-2 ${
              loading || !input.trim() ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            <Send className="w-4 h-4" />
            Invia
          </button>
        </form>

      </div>

    </div>
  );
};

