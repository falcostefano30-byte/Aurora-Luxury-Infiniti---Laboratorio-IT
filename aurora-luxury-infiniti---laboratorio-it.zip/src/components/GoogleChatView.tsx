import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn, googleSignOut, getCachedToken } from '../services/chatAuth';
import { MessageSquare, Send, Sparkles, LogOut, RefreshCw, Hash, Users, ShieldAlert, Bot } from 'lucide-react';

interface Space {
  name: string;
  displayName?: string;
  spaceType?: string;
  threaded?: boolean;
}

interface Message {
  name: string;
  sender?: {
    name: string;
    displayName: string;
    type: string;
  };
  text?: string;
  createTime?: string;
}

export const GoogleChatView: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [spaces, setSpaces] = useState<Space[]>([]);
  const [selectedSpace, setSelectedSpace] = useState<Space | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loadingSpaces, setLoadingSpaces] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (u, t) => {
        setUser(u);
        setToken(t);
        setLoadingAuth(false);
        fetchSpaces(t);
      },
      () => {
        setUser(null);
        setToken(null);
        setLoadingAuth(false);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    setError(null);
    const res = await googleSignIn();
    if (res) {
      setUser(res.user);
      setToken(res.accessToken);
      fetchSpaces(res.accessToken);
    } else {
      setError("Autenticazione Google non riuscita. Riprova.");
    }
  };

  const handleSignOut = async () => {
    await googleSignOut();
    setUser(null);
    setToken(null);
    setSpaces([]);
    setSelectedSpace(null);
    setMessages([]);
  };

  const fetchSpaces = async (accessToken: string) => {
    setLoadingSpaces(true);
    setError(null);
    try {
      const res = await fetch('https://chat.googleapis.com/v1/spaces', {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Errore HTTP ${res.status}`);
      }
      const data = await res.json();
      const fetchedSpaces = data.spaces || [];
      setSpaces(fetchedSpaces);
      if (fetchedSpaces.length > 0 && !selectedSpace) {
        setSelectedSpace(fetchedSpaces[0]);
        fetchMessages(accessToken, fetchedSpaces[0].name);
      }
    } catch (err: any) {
      console.error('Failed to fetch spaces:', err);
      setError(`Impossibile caricare gli spazi di Google Chat: ${err.message}. Assicurati che l'API Google Chat sia abilitata nel progetto Cloud.`);
    } finally {
      setLoadingSpaces(false);
    }
  };

  const fetchMessages = async (accessToken: string, spaceName: string) => {
    setLoadingMessages(true);
    setError(null);
    try {
      const res = await fetch(`https://chat.googleapis.com/v1/${spaceName}/messages`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Errore HTTP ${res.status}`);
      }
      const data = await res.json();
      setMessages(data.messages || []);
    } catch (err: any) {
      console.error('Failed to fetch messages:', err);
      setError(`Impossibile caricare i messaggi: ${err.message}`);
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedSpace || !token) return;

    const textToSend = newMessage.trim();
    setNewMessage('');

    try {
      const res = await fetch(`https://chat.googleapis.com/v1/${selectedSpace.name}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: textToSend })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `Errore HTTP ${res.status}`);
      }

      // Refresh messages
      fetchMessages(token, selectedSpace.name);
    } catch (err: any) {
      console.error('Failed to send message:', err);
      setError(`Impossibile inviare il messaggio: ${err.message}`);
    }
  };

  if (loadingAuth) {
    return (
      <div className="flex items-center justify-center h-96 text-cyan-400 font-mono text-sm animate-pulse">
        Caricamento autenticazione Google Chat...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" /> Integrazione Google Chat Ufficiale
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Aurora Luxury <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Infiniti Chat</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Gestisci spazi, conversazioni e messaggi di Google Chat direttamente dall'interfaccia quantistica di Aurora.
            </p>
          </div>

          {user && (
            <div className="flex items-center gap-3 bg-slate-950/80 border border-slate-800 px-4 py-2.5 rounded-2xl">
              {user.photoURL && (
                <img src={user.photoURL} alt={user.displayName || 'User'} className="w-9 h-9 rounded-full border border-cyan-400" />
              )}
              <div className="text-left font-mono">
                <div className="text-xs font-bold text-white">{user.displayName}</div>
                <div className="text-[10px] text-slate-400">{user.email}</div>
              </div>
              <button
                onClick={handleSignOut}
                className="ml-2 p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 transition-all"
                title="Disconnetti"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-mono flex items-center gap-3">
          <ShieldAlert className="w-5 h-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {!user ? (
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-12 text-center shadow-xl space-y-6 max-w-xl mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mx-auto shadow-inner">
            <MessageSquare className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-bold text-white font-mono">Connetti Google Chat</h3>
            <p className="text-sm text-slate-300">
              Accedi con il tuo account Google per autorizzare Aurora Luxury Infiniti ad accedere ai tuoi spazi e messaggi Google Chat.
            </p>
          </div>

          <div className="flex justify-center pt-2">
            <button
              onClick={handleSignIn}
              className="gsi-material-button relative inline-flex items-center justify-center px-6 py-3 rounded-2xl bg-white text-slate-900 font-medium text-sm shadow-lg hover:bg-slate-100 transition-all cursor-pointer border border-slate-300"
            >
              <div className="gsi-material-button-icon mr-3 w-5 h-5 flex items-center justify-center">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-5 h-5">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                  <path fill="none" d="M0 0h48v48H0z"></path>
                </svg>
              </div>
              <span className="gsi-material-button-contents font-sans font-semibold">Sign in with Google</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Spaces Sidebar */}
          <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 font-mono text-xs text-white font-bold">
                <Hash className="w-4 h-4 text-cyan-400" /> Spazi Google Chat ({spaces.length})
              </div>
              <button
                onClick={() => token && fetchSpaces(token)}
                className="p-1.5 rounded-lg bg-slate-950 text-slate-400 hover:text-white border border-slate-800 transition-all"
                title="Aggiorna Spazi"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingSpaces ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {loadingSpaces ? (
              <div className="text-center py-12 text-slate-500 font-mono text-xs animate-pulse">
                Caricamento spazi in corso...
              </div>
            ) : spaces.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs font-mono">
                Nessuno spazio trovato. Crea o unisciti a uno spazio su Google Chat.
              </div>
            ) : (
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                {spaces.map((space) => (
                  <button
                    key={space.name}
                    onClick={() => {
                      setSelectedSpace(space);
                      if (token) fetchMessages(token, space.name);
                    }}
                    className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                      selectedSpace?.name === space.name
                        ? 'bg-cyan-500/10 border-cyan-500/40 text-white shadow'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="truncate">
                      <div className="font-bold text-xs truncate font-mono">
                        {space.displayName || space.name}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {space.spaceType || 'SPACE'}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Messages Main Pane */}
          <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-3xl shadow-xl flex flex-col h-[550px] overflow-hidden">
            
            <div className="px-6 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-mono">
                    {selectedSpace?.displayName || selectedSpace?.name || 'Seleziona uno spazio'}
                  </h3>
                  <p className="text-[11px] text-emerald-400 font-mono">
                    Aurora Luxury Infiniti • Google Chat Connesso
                  </p>
                </div>
              </div>

              {selectedSpace && token && (
                <button
                  onClick={() => fetchMessages(token, selectedSpace.name)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 text-slate-300 hover:text-white border border-slate-800 text-xs font-mono flex items-center gap-1.5 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingMessages ? 'animate-spin' : ''}`} /> Aggiorna
                </button>
              )}
            </div>

            {/* Messages List */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-950/40">
              {!selectedSpace ? (
                <div className="h-full flex items-center justify-center text-slate-500 font-mono text-xs">
                  Seleziona uno spazio Google Chat dal pannello a sinistra per visualizzare i messaggi.
                </div>
              ) : loadingMessages ? (
                <div className="h-full flex items-center justify-center text-slate-500 font-mono text-xs animate-pulse">
                  Caricamento messaggi dallo spazio...
                </div>
              ) : messages.length === 0 ? (
                <div className="h-full flex items-center justify-center text-slate-500 font-mono text-xs">
                  Nessun messaggio in questo spazio. Invia il primo messaggio qui sotto!
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div key={msg.name || idx} className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1 shadow-md">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-cyan-400 font-bold">
                        {msg.sender?.displayName || 'Utente'}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {msg.createTime ? new Date(msg.createTime).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : ''}
                      </span>
                    </div>
                    <p className="text-sm text-slate-200 leading-relaxed font-sans">
                      {msg.text || '[Messaggio multimediale]'}
                    </p>
                  </div>
                ))
              )}
            </div>

            {/* Send Message Input */}
            {selectedSpace && (
              <form onSubmit={handleSendMessage} className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-3">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={`Scrivi un messaggio in ${selectedSpace.displayName || 'questo spazio'}...`}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-5 py-3 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono transition-all"
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" /> Invia
                </button>
              </form>
            )}

          </div>

        </div>
      )}

    </div>
  );
};
