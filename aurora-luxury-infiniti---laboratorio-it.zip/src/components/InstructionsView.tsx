import React, { useState } from 'react';
import { BookOpen, Cpu, Briefcase, CreditCard, TrendingUp, ShieldCheck, Sparkles, CheckCircle2, ShieldAlert, Bot, ArrowRight, DollarSign, Lock, Globe, ChevronRight, X, ExternalLink } from 'lucide-react';

interface GuideSection {
  id: string;
  title: string;
  subtitle: string;
  icon: any;
  color: string;
  badge: string;
  summary: string;
  steps: string[];
  details: string[];
  warning?: string;
}

export const InstructionsView: React.FC = () => {
  const [selectedGuide, setSelectedGuide] = useState<GuideSection | null>(null);

  const guides: GuideSection[] = [
    {
      id: 'money-withdrawal',
      title: 'Come Funziona il Denaro & Come Prelevare',
      subtitle: 'Guida definitiva alla gestione del capitale, dei guadagni e dei bonifici',
      icon: DollarSign,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      badge: 'Fondata su Dati Reali & Gateway',
      summary: 'Scopri come si accumula il denaro nel sistema tramite i micro-lavori e come eseguire prelievi sicuri su qualsiasi banca o circuito.',
      steps: [
        'Accedi alla sezione "Conto & Trasferisci" tramite il menu principale.',
        'Verifica il saldo disponibile in tempo reale nel riquadro superiore.',
        'Inserisci l\'importo esatto che desideri trasferire (es. € 500,00).',
        'Seleziona la banca o il circuito di destinazione dalla legenda (Intesa Sanpaolo, Revolut, Coinbase, PayPal, Stripe, ecc.).',
        'Inserisci il numero di conto, IBAN o carta, il nome del titolare e la causale.',
        'Clicca su "Trasferisci Fondi Ora" per completare il bonifico e aggiornare lo storico.'
      ],
      details: [
        'I guadagni derivano direttamente dai task completati dal motore autonomo di Aurora.',
        'Tutte le transazioni vengono registrate in modo crittografato e tracciabile.',
        'Il sistema supporta banche tradizionali, neobanche digitali e circuiti crypto con elaborazione istantanea.'
      ],
      warning: 'Assicurati di inserire un IBAN o un numero di carta valido prima di confermare il trasferimento per evitare ritardi interbancari.'
    },
    {
      id: 'work-aurora',
      title: 'Lavoro di Aurora (Automazione 24/7)',
      subtitle: 'Motore di scansione micro-incarichi e accredito automatico',
      icon: Briefcase,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
      badge: 'Loop Autonomo',
      summary: 'Guida all\'uso del pulsante "Avvia Scansione e Svolgi Lavoro" per generare entrate continue e monitorare il terminale in streaming.',
      steps: [
        'Apri il menu e seleziona "Lavoro di Aurora".',
        'Clicca sul pulsante "Avvia Scansione e Svolgi Lavoro" per attivare il loop automatico.',
        'Osserva il terminale live in tempo reale che mostra le scansioni e il completamento degli incarichi.',
        'Prendi nota del codice incarico (ID task) per accedere al servizio partner.',
        'Premi nuovamente lo stesso pulsante per fermare l\'automazione in qualsiasi momento.'
      ],
      details: [
        'Ogni mansione completata viene accreditata istantaneamente nel capitale totale.',
        'Il sistema genera automaticamente codici univoci per la verifica ufficiale sui portali esterni.',
        'Il registro delle mansioni elenca data, committente, durata e compenso esatto.'
      ],
      warning: 'Il meccanismo continua a lavorare in background finché non viene fermato manualmente dall\'utente.'
    },
    {
      id: 'wallet-transfer',
      title: 'Conto & Trasferisci (Banche & Legenda)',
      subtitle: 'Gestione fondi e legenda completa dei circuiti bancari',
      icon: CreditCard,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
      badge: 'Circuiti Globali',
      summary: 'Come utilizzare il portafoglio digitale e consultare la legenda dei circuiti di pagamento supportati.',
      steps: [
        'Seleziona "Conto & Trasferisci" dal menu principale.',
        'Consulta l\'elenco completo nella legenda per identificare la tua banca (Intesa Sanpaolo, UniCredit, Poste Italiane, N26, Wise, ecc.).',
        'Compila il modulo di bonifico con i dati richiesti.',
        'Controlla lo storico transazioni in fondo alla pagina per verificare lo stato di ogni trasferimento.'
      ],
      details: [
        'Sono supportati 15+ circuiti bancari e finanziari tra cui SEPA, Swift, Crypto e Gateway.',
        'Ogni transazione completata riduce il saldo disponibile e genera una ricevuta digitale.'
      ]
    },
    {
      id: 'trading-module',
      title: 'Aurora Trading & Analisi Mercati',
      subtitle: 'Monitoraggio asset finanziari e criptovalute',
      icon: TrendingUp,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
      badge: 'Real-Time Markets',
      summary: 'Come consultare i grafici di volatilità e monitorare l\'andamento degli asset digitali.',
      steps: [
        'Entra nella sezione "Aurora Trading" dal menu.',
        'Visualizza i grafici interattivi con andamento percentuale e volumi.',
        'Usa gli strumenti di analisi per valutare le tendenze di mercato.'
      ],
      details: [
        'Aggiornamenti in tempo reale dei principali indici e criptovalute.',
        'Interfaccia ottimizzata per la lettura rapida dei trend finanziari.'
      ]
    },
    {
      id: 'treasury-vault',
      title: 'Treasury & Vault (+50% Bonus)',
      subtitle: 'Rendiconto contabile e bonus settimanale',
      icon: ShieldCheck,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      badge: 'Tesoreria Ufficiale',
      summary: 'Come funziona il registro contabile e l\'accredito automatico del bonus del 50% sul saldo.',
      steps: [
        'Apri la sezione "Treasury & Vault" dal menu.',
        'Visualizza il rendiconto contabile di tutte le entrate e uscite.',
        'Controlla l\'attivazione del bonus settimanale del +50% sul capitale.'
      ],
      details: [
        'Il Vault garantisce la massima trasparenza contabile di tutte le attività della piattaforma.',
        'Il bonus settimanale viene calcolato automaticamente dal motore finanziario.'
      ]
    },
    {
      id: 'ai-control',
      title: 'Pannello Aurora & AI (Chat Intelligente)',
      subtitle: 'Assistente vocale e reindirizzamento prelievi',
      icon: Bot,
      color: 'text-sky-400 bg-sky-500/10 border-sky-500/30',
      badge: 'Gemini 2.5 Flash',
      summary: 'Come comunicare con Aurora e sfruttare il reindirizzamento automatico per i prelievi.',
      steps: [
        'Seleziona "Pannello Aurora & AI" dal menu.',
        'Scrivi un messaggio nella chat (es. "voglio prelevare i miei guadagni").',
        'Aurora ti risponderà e attiverà il reindirizzamento sicuro al portale ufficiale.'
      ],
      details: [
        'Alimentato dal modello avanzato Google Gemini.',
        'Gestisce richieste di supporto e transazioni in linguaggio naturale.'
      ]
    },
    {
      id: 'kill-switch',
      title: 'Kill Switch (Protocollo d\'Emergenza)',
      subtitle: 'Timer digitale e codici di sicurezza',
      icon: ShieldAlert,
      color: 'text-red-400 bg-red-500/10 border-red-500/30',
      badge: 'Sicurezza Estrema',
      summary: 'Come attivare il conto alla rovescia con millisecondi e come sbloccare il sistema con i codici.',
      steps: [
        'Apri "Kill Switch (Emergenza)" dal menu principale.',
        'Digita <code class="text-emerald-400 font-mono">one</code> nel riquadro verde per avviare il conto alla rovescia di 30 minuti con visualizzazione millisecondi.',
        'Digita <code class="text-red-400 font-mono">karnak089</code> nel riquadro rosso per bloccare, disarmare e proteggere il sistema.'
      ],
      details: [
        'Se il timer scade senza sblocco, i dati locali vengono eliminati per massima sicurezza.',
        'Progettato come protocollo di protezione estrema.'
      ],
      warning: 'Utilizzare il Kill Switch solo in caso di effettiva necessità di emergenza.'
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-6">
      
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
            <BookOpen className="w-3.5 h-3.5" /> Manuale Operativo & Guida Interattiva Minuziosa
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            Istruzioni & Manuale • <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Aurora Luxury Infiniti</span>
          </h2>
          <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
            Clicca su una qualsiasi delle funzioni sottostanti per aprire la spiegazione dettagliata e minuziosa, con tutti i passaggi operativi per prelevare denaro, gestire i task e usare la piattaforma.
          </p>
        </div>
      </div>

      {/* Grid of Interactive Function Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {guides.map((guide) => {
          const IconComponent = guide.icon;
          return (
            <div
              key={guide.id}
              onClick={() => setSelectedGuide(guide)}
              className="group bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-3xl p-6 shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-4 transform hover:-translate-y-1"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${guide.color}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] font-mono px-3 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {guide.badge}
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                    {guide.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">{guide.subtitle}</p>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {guide.summary}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-bold text-cyan-400 group-hover:text-cyan-300">
                <span>Leggi spiegazione dettagliata</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Modal Popup when a function is clicked */}
      {selectedGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center border ${selectedGuide.color}`}>
                  <selectedGuide.icon className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">{selectedGuide.badge}</span>
                  <h3 className="text-lg font-bold text-white">{selectedGuide.title}</h3>
                </div>
              </div>
              <button
                onClick={() => setSelectedGuide(null)}
                className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
              
              {/* Summary */}
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl">
                <p className="text-xs text-slate-200 leading-relaxed font-medium">
                  {selectedGuide.summary}
                </p>
              </div>

              {/* Steps */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Procedura Operativa Passo-Passo
                </h4>
                <div className="space-y-2">
                  {selectedGuide.steps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-3 bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                      <span className="w-6 h-6 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center justify-center font-mono text-xs font-bold shrink-0">
                        {idx + 1}
                      </span>
                      <p className="text-xs text-slate-200 leading-relaxed pt-0.5" dangerouslySetInnerHTML={{ __html: step }}></p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Additional Technical Details */}
              {selectedGuide.details && selectedGuide.details.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold flex items-center gap-2">
                    <Sparkles className="w-4 h-4" /> Dettagli Tecnici & Note Avanzate
                  </h4>
                  <ul className="space-y-2 pl-2">
                    {selectedGuide.details.map((detail, idx) => (
                      <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                        <span className="text-cyan-400 mt-1">•</span>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Warning Notice if present */}
              {selectedGuide.warning && (
                <div className="bg-amber-950/40 border border-amber-500/40 p-4 rounded-2xl flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-200 leading-relaxed">
                    <strong>Nota Importante:</strong> {selectedGuide.warning}
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/50 flex justify-end">
              <button
                onClick={() => setSelectedGuide(null)}
                className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs uppercase tracking-wider transition-all"
              >
                Chiudi Guida
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
