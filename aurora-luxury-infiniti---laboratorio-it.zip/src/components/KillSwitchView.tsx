import React, { useState, useEffect } from 'react';
import { ShieldAlert, Play, Lock, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

export default function KillSwitchView() {
  const [totalMs, setTotalMs] = useState(30 * 60 * 1000); // 30 minutes in milliseconds
  const [isActive, setIsActive] = useState(false);
  const [activationInput, setActivationInput] = useState('');
  const [disarmInput, setDisarmInput] = useState('');
  const [destroyed, setDestroyed] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // High-precision millisecond countdown timer
  useEffect(() => {
    let interval: any = null;
    if (isActive && totalMs > 0 && !destroyed) {
      const startTime = Date.now();
      const initialMs = totalMs;

      interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const remaining = initialMs - elapsed;
        if (remaining <= 0) {
          setTotalMs(0);
          setDestroyed(true);
          localStorage.clear();
          sessionStorage.clear();
          clearInterval(interval);
        } else {
          setTotalMs(remaining);
        }
      }, 31); // ~30fps for smooth millisecond updates
    }
    return () => clearInterval(interval);
  }, [isActive, destroyed]);

  // Format milliseconds into HH:MM:SS.SSS
  const formatDigitalTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    const millis = Math.floor((ms % 1000) / 10); // 2 digits millis for display

    return {
      h: hours.toString().padStart(2, '0'),
      m: minutes.toString().padStart(2, '0'),
      s: seconds.toString().padStart(2, '0'),
      ms: millis.toString().padStart(2, '0')
    };
  };

  // Handle activation using password "one"
  const handleActivateWithOne = (e: React.FormEvent) => {
    e.preventDefault();
    if (activationInput.trim().toLowerCase() === 'one') {
      if (window.confirm("⚠️ ATTENZIONE: Confermi l'attivazione del Kill Switch di emergenza?")) {
        setIsActive(true);
        setTotalMs(30 * 60 * 1000);
        setErrorMsg('');
        setSuccessMsg('🚨 PROTOCOLLO KILL SWITCH ATTIVATO!');
        setActivationInput('');
      }
    } else {
      setErrorMsg("❌ Codice di attivazione errato! Inserisci 'one'.");
    }
  };

  // Handle disarm using password "karnak089"
  const handleDisarmWithKarnak = (e: React.FormEvent) => {
    e.preventDefault();
    if (disarmInput.trim() === 'karnak089') {
      setIsActive(false);
      setDestroyed(false);
      setTotalMs(30 * 60 * 1000);
      setDisarmInput('');
      setErrorMsg('');
      setSuccessMsg('✅ Sistema sbloccato e disarmato con successo!');
      setTimeout(() => setSuccessMsg(''), 5000);
    } else {
      setErrorMsg("❌ Codice di sblocco errato! Inserisci 'karnak089'.");
    }
  };

  const timeParts = formatDigitalTime(totalMs);

  if (destroyed) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-black text-red-600 p-8 rounded-3xl border-2 border-red-900 font-mono shadow-[0_0_80px_-15px_#ef4444]">
        <div className="animate-pulse text-center space-y-4">
          <ShieldAlert className="w-20 h-20 text-red-500 mx-auto animate-bounce" />
          <h1 className="text-5xl font-black tracking-tighter text-red-500">🛑 PROTOCOLLO COMPLETATO</h1>
          <p className="text-lg text-gray-300 max-w-md mx-auto">
            Tempo scaduto. Tutti i dati locali e le sessioni sono stati eliminati permanentemente dal sistema.
          </p>
          <button 
            onClick={() => { setDestroyed(false); setTotalMs(30*60*1000); setIsActive(false); }}
            className="mt-6 bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 mx-auto"
          >
            <RefreshCw className="w-4 h-4 animate-spin" /> Riavvia Sistema di Sicurezza
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col items-center justify-center max-w-4xl mx-auto bg-slate-950 text-white p-8 rounded-3xl border border-red-500/40 shadow-[0_0_60px_-15px_rgba(239,68,68,0.3)] overflow-hidden my-6">
      
      {/* Emergency red ambient glow when active */}
      {isActive && (
        <div className="absolute inset-0 bg-red-950/30 animate-pulse pointer-events-none"></div>
      )}

      <div className="relative z-10 w-full space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-mono uppercase tracking-widest">
            <ShieldAlert className="w-4 h-4 animate-pulse" /> Sistema di Sicurezza Critico
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-red-500">
            KILL SWITCH • EMERGENZA ESTREMA
          </h2>
          <p className="text-xs text-amber-300/90 bg-amber-950/40 border border-amber-500/30 p-3 rounded-2xl max-w-xl mx-auto leading-relaxed">
            ⚠️ <strong>Avviso di sicurezza:</strong> L'attivazione con il codice <code className="text-cyan-400 font-mono">one</code> avvia il conto alla rovescia definitivo. Se scade, i dati locali vengono cancellati. Inserisci <code className="text-red-400 font-mono">karnak089</code> nel riquadro rosso per bloccare e disarmare il sistema.
          </p>
        </div>

        {/* Big Digital Clock Display */}
        <div className="bg-black/80 border-2 border-red-500/40 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-2 left-4 text-[10px] font-mono text-red-400/80 tracking-widest uppercase">
            {isActive ? '🔴 STATO: CONTO ALLA ROVESCIA IN CORSO' : '🟢 STATO: SISTEMA ARMATO IN STANDBY'}
          </div>

          <div className="flex items-center justify-center gap-2 font-mono text-5xl md:text-7xl font-black text-red-500 tracking-wider my-4 drop-shadow-[0_0_15px_rgba(239,68,68,0.6)]">
            <span>{timeParts.h}</span>
            <span className="animate-pulse">:</span>
            <span>{timeParts.m}</span>
            <span className="animate-pulse">:</span>
            <span>{timeParts.s}</span>
            <span className="text-3xl md:text-4xl text-red-400/80">.{timeParts.ms}</span>
          </div>

          <div className="text-xs font-mono text-slate-400 uppercase tracking-widest">
            Ore : Minuti : Secondi . Millisecondi
          </div>
        </div>

        {/* Success / Error Banners */}
        {errorMsg && (
          <div className="bg-red-950/80 border border-red-500 text-red-200 p-3 rounded-xl text-xs font-medium text-center animate-shake">
            {errorMsg}
          </div>
        )}
        {successMsg && (
          <div className="bg-emerald-950/80 border border-emerald-500 text-emerald-200 p-3 rounded-xl text-xs font-medium text-center">
            {successMsg}
          </div>
        )}

        {/* Two Action Boxes underneath */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* GREEN BOX: Activation with password "one" */}
          <div className="bg-slate-900/90 border border-emerald-500/40 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Play className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Attivazione Protocollo</h3>
                <p className="text-[11px] text-slate-400">Digita <span className="text-emerald-400 font-mono font-bold">one</span> per avviare</p>
              </div>
            </div>

            <form onSubmit={handleActivateWithOne} className="space-y-3">
              <input
                type="text"
                value={activationInput}
                onChange={(e) => setActivationInput(e.target.value)}
                placeholder="Digita 'one' qui..."
                disabled={isActive}
                className="w-full bg-slate-950 border border-emerald-500/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-emerald-400 font-mono disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isActive || !activationInput.trim()}
                className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2 cursor-pointer"
              >
                🟢 Avvia Conto alla Rovescia
              </button>
            </form>
          </div>

          {/* RED BOX: Disarm / Block with password "karnak089" */}
          <div className="bg-slate-900/90 border border-red-500/40 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Blocco & Sblocco di Sicurezza</h3>
                <p className="text-[11px] text-slate-400">Digita <span className="text-red-400 font-mono font-bold">karnak089</span> per bloccare</p>
              </div>
            </div>

            <form onSubmit={handleDisarmWithKarnak} className="space-y-3">
              <input
                type="password"
                value={disarmInput}
                onChange={(e) => setDisarmInput(e.target.value)}
                placeholder="Digita 'karnak089' qui..."
                className="w-full bg-slate-950 border border-red-500/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-red-400 font-mono"
              />
              <button
                type="submit"
                disabled={!disarmInput.trim()}
                className="w-full bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-bold py-3 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40 flex items-center justify-center gap-2 cursor-pointer"
              >
                🔴 Blocca / Disarma Sistema
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
}
