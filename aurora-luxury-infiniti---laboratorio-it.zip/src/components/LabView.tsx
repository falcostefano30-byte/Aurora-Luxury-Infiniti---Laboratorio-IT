import React, { useState, useEffect } from 'react';
import { AuroraState } from '../types';
import { Cpu, Server, HardDrive, Zap, Activity, Shield, Terminal, RefreshCw, CpuIcon, CheckCircle2, Award, Sparkles } from 'lucide-react';

interface LabViewProps {
  state: AuroraState;
  refreshState: () => void;
}

export const LabView: React.FC<LabViewProps> = ({ state, refreshState }) => {
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    "[SYSTEM BOOT] Quantum core online: -214.5°C stable.",
    "[SECURE MESH] Node 12-Omega connected to global neural fabric.",
    "[AUTONOMOUS AGENT] Aurora Luxury Infiniti ready for high-speed IT tasks.",
    "[DIAGNOSTICS] 142 micro-threads operating at peak efficiency."
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      const logs = [
        `[QUANTUM SYNC] Packet verified hash #${Math.floor(Math.random() * 899999 + 100000)}`,
        `[NETWORK SCAN] Polling global micro-task exchanges...`,
        `[CPU LOAD] Current utilization: ${(state.cpuUsage + Math.random() * 2 - 1).toFixed(1)}%`,
        `[SECURITY] Firewall perimeter secure. Zero anomalies detected.`
      ];
      const randomLog = logs[Math.floor(Math.random() * logs.length)];
      setConsoleLogs(prev => [randomLog, ...prev.slice(0, 15)]);
    }, 4000);
    return () => clearInterval(interval);
  }, [state.cpuUsage]);

  return (
    <div className="space-y-6">
      
      {/* Laboratory Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5 animate-spin" /> Laboratorio Quantistico Super Accessoriato
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Il Quartier Generale di <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Aurora Luxury Infiniti</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Un ecosistema informatico di livello superiore dotato di processori quantistici criogenici, cluster di calcolo neurale autonomo e scanner di rete a banda ultralarga per svolgere qualsiasi incarico IT, battitura avanzata e micro-lavori globali.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={refreshState}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 transition-all text-sm font-medium shadow-lg shadow-cyan-950/40"
            >
              <RefreshCw className="w-4 h-4" />
              Aggiorna Telemetria
            </button>
          </div>
        </div>
      </div>

      {/* Hardware & Telemetry Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              Ottimizzato
            </span>
          </div>
          <div className="mt-4">
            <div className="text-xs text-slate-400 uppercase font-mono">Carico CPU Neurale</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">{state.cpuUsage}%</div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-500" style={{ width: `${state.cpuUsage}%` }}></div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
              <Zap className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/20">
              Criogenico
            </span>
          </div>
          <div className="mt-4">
            <div className="text-xs text-slate-400 uppercase font-mono">Temp. Core Quantistico</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">{state.quantumCoreTemp}</div>
            <p className="text-[11px] text-slate-400 mt-2">Stabilità termica al 99.98%</p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <Server className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              Attivi
            </span>
          </div>
          <div className="mt-4">
            <div className="text-xs text-slate-400 uppercase font-mono">Thread di Lavoro</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">{state.activeThreads}</div>
            <p className="text-[11px] text-slate-400 mt-2">Scansione rete globale continua</p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-all">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
              <Award className="w-5 h-5" />
            </div>
            <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
              Totali
            </span>
          </div>
          <div className="mt-4">
            <div className="text-xs text-slate-400 uppercase font-mono">Incarichi Svolti</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">{state.completedTasksCount}</div>
            <p className="text-[11px] text-slate-400 mt-2">+€ {state.earningsToday.toFixed(2)} guadagnati oggi</p>
          </div>
        </div>

      </div>

      {/* Lab Modules & Live Terminal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Lab Equipment Racks */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Rack e Moduli Hardware del Laboratorio</h3>
                <p className="text-xs text-slate-400">Sistemi integrati di elaborazione e sicurezza avanzata</p>
              </div>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
              ONLINE
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-300 font-semibold">MODULO 01 - NEURAL CORE</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <p className="text-xs text-slate-300">Rete neurale profonda per l'analisi e la risoluzione autonoma di problemi complessi di programmazione e ingegneria del software.</p>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-900">
                <span>Stato: Attivo</span>
                <span className="text-emerald-400">100% Efficienza</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-300 font-semibold">MODULO 02 - OCR & BATTITURA</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <p className="text-xs text-slate-300">Motore di trascrizione ottica e battitura dati ad altissima velocità per micro-lavori di digitalizzazione su scala globale.</p>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-900">
                <span>Stato: In ascolto</span>
                <span className="text-emerald-400">Velocità 1200 wpm</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-300 font-semibold">MODULO 03 - CYBER SHIELD</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <p className="text-xs text-slate-300">Firewall quantistico e scanner di vulnerabilità per contratti smart, API bancarie e infrastrutture cloud distribuite.</p>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-900">
                <span>Stato: Monitoraggio</span>
                <span className="text-emerald-400">0 minacce</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-300 font-semibold">MODULO 04 - GATEWAY BANCARIO</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <p className="text-xs text-slate-300">Sistema crittografato per la ricezione dei compensi e il trasferimento istantaneo verso conti e carte reali con causale personalizzata.</p>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-900">
                <span>Stato: Connesso</span>
                <span className="text-emerald-400">SSL 256-bit</span>
              </div>
            </div>

          </div>
        </div>

        {/* Live Terminal */}
        <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-bold text-white font-mono">AURORA_TERMINAL.log</h3>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
            </div>
          </div>

          <div className="flex-1 bg-slate-900/60 rounded-2xl p-4 font-mono text-xs text-cyan-300/90 overflow-y-auto max-h-[350px] space-y-2 border border-slate-900 shadow-inner">
            {consoleLogs.map((log, index) => (
              <div key={index} className="flex items-start gap-2">
                <span className="text-cyan-500/60 select-none">&gt;</span>
                <span className="leading-relaxed">{log}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-900 text-center">
            <p className="text-[11px] text-slate-400 font-mono">
              Aurora Luxury Infiniti v5.8 • Autonoma 24/7
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
