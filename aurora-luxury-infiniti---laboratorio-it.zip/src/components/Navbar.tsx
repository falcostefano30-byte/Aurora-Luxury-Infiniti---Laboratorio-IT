import React, { useState, useRef, useEffect } from 'react';
import { Cpu, Zap, CreditCard, Terminal, Sparkles, Activity, ShieldCheck, TrendingUp, MessageSquare, BookOpen, ShieldAlert, Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  balance: number;
  status: string;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, balance, status }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const menuItems = [
    { id: 'lab', label: 'Laboratorio IT', icon: Cpu, color: 'text-cyan-400' },
    { id: 'work', label: 'Lavoro di Aurora', icon: Zap, color: 'text-indigo-400' },
    { id: 'wallet', label: 'Conto & Trasferisci', icon: CreditCard, color: 'text-emerald-400' },
    { id: 'trading', label: 'Aurora Trading', icon: TrendingUp, color: 'text-[#00ff88]' },
    { id: 'treasury', label: 'Treasury & Vault', icon: ShieldCheck, color: 'text-cyan-300' },
    { id: 'instructions', label: 'Istruzioni & Manuale', icon: BookOpen, color: 'text-sky-400' },
    { id: 'killswitch', label: 'Kill Switch (Emergenza)', icon: ShieldAlert, color: 'text-red-400' },
  ];

  const currentTabObj = menuItems.find(item => item.id === activeTab) || menuItems[0];
  const CurrentIcon = currentTabObj.icon;

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/85 border-b border-cyan-500/20 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Logo & Identity */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 blur-sm opacity-70 animate-pulse"></div>
            <div className="relative w-11 h-11 rounded-full bg-slate-900 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base lg:text-lg font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-100 to-indigo-300">
                AURORA LUXURY INFINITI
              </h1>
              <span className="hidden sm:inline-block text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 uppercase tracking-widest font-mono">
                AI Elite
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="font-mono text-emerald-400 truncate max-w-xs">{status}</span>
            </p>
          </div>
        </div>

        {/* Right side: Menu Toggle & Live Balance */}
        <div className="flex items-center gap-3">
          
          {/* Collapsible Menu Button */}
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-white font-medium text-xs shadow-lg shadow-cyan-950/40 transition-all cursor-pointer"
            >
              <CurrentIcon className={`w-4 h-4 ${currentTabObj.color}`} />
              <span className="hidden sm:inline">{currentTabObj.label}</span>
              <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${menuOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Dropdown Menu */}
            {menuOpen && (
              <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-slate-900 border border-cyan-500/30 shadow-2xl p-2 z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-2 border-b border-slate-800 mb-1">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
                    Menu Applicazioni & Moduli
                  </span>
                </div>
                <div className="space-y-1">
                  {menuItems.map((item) => {
                    const ItemIcon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                          isActive
                            ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                            : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                        }`}
                      >
                        <ItemIcon className={`w-4 h-4 ${isActive ? 'text-white' : item.color}`} />
                        <span className="flex-1">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Live Balance Widget */}
          <div className="flex items-center gap-3 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 px-4 py-2 rounded-2xl border border-cyan-500/30 shadow-lg shadow-cyan-950/40">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[9px] text-slate-400 uppercase font-mono tracking-wider">Capitale</div>
              <div className="text-sm lg:text-base font-bold font-mono text-cyan-300">
                € {balance.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};
