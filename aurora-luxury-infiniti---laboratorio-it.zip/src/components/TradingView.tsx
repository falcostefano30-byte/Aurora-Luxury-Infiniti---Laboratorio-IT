import React, { useState, useEffect, useRef } from 'react';
import { AuroraState } from '../types';
import { TrendingUp, Play, Pause, ShieldAlert, DollarSign, Activity, BarChart2, Zap, RefreshCw, CheckCircle2, Globe, Cpu, Layers, CreditCard, ArrowUpRight, Wallet, Flame, Shield } from 'lucide-react';

interface TradingViewProps {
  state: AuroraState;
  refreshState: () => void;
}

interface WorldAsset {
  symbol: string;
  name: string;
  category: 'Azioni' | 'Metalli & Oro' | 'Energia & Petrolio' | 'Materiali' | 'Alimentari';
  price: number;
  change: number;
  high: number;
  low: number;
  vol: string;
}

const WORLD_WIDE_ASSETS: WorldAsset[] = [
  // Metalli & Oro
  { symbol: "XAU-USD", name: "Oro Spot (Gold)", category: "Metalli & Oro", price: 2684.50, change: 0.85, high: 2692.0, low: 2671.0, vol: "42.8B" },
  { symbol: "XAG-USD", name: "Argento Spot (Silver)", category: "Metalli & Oro", price: 31.85, change: 1.42, high: 32.20, low: 31.40, vol: "18.5B" },
  { symbol: "COPPER", name: "Rame Industriale", category: "Metalli & Oro", price: 4.42, change: -0.35, high: 4.48, low: 4.39, vol: "12.1B" },
  { symbol: "ALUM", name: "Alluminio LME", category: "Metalli & Oro", price: 2540.0, change: 0.22, high: 2560.0, low: 2525.0, vol: "8.4B" },
  { symbol: "NICKEL", name: "Nichel Global", category: "Metalli & Oro", price: 16850.0, change: -1.10, high: 17100.0, low: 16720.0, vol: "5.6B" },

  // Energia & Petrolio
  { symbol: "BRENT", name: "Petrolio Brent Crude", category: "Energia & Petrolio", price: 74.85, change: 1.15, high: 75.60, low: 73.90, vol: "88.4B" },
  { symbol: "WTI", name: "Petrolio WTI Crude", category: "Energia & Petrolio", price: 71.20, change: 0.98, high: 71.95, low: 70.30, vol: "74.2B" },
  { symbol: "NATGAS", name: "Gas Naturale Henry Hub", category: "Energia & Petrolio", price: 2.84, change: -2.40, high: 2.95, low: 2.80, vol: "14.9B" },
  { symbol: "DIESEL", name: "Carburante Diesel", category: "Energia & Petrolio", price: 2.38, change: 0.45, high: 2.42, low: 2.35, vol: "9.8B" },
  { symbol: "GASOLINE", name: "Benzina RBOB", category: "Energia & Petrolio", price: 2.12, change: 0.62, high: 2.15, low: 2.09, vol: "11.2B" },

  // Beni Alimentari
  { symbol: "WHEAT", name: "Grano Tenero CBOT", category: "Alimentari", price: 584.25, change: 0.75, high: 590.0, low: 578.0, vol: "6.2B" },
  { symbol: "CORN", name: "Mais Globale", category: "Alimentari", price: 422.50, change: -0.15, high: 426.0, low: 420.0, vol: "7.5B" },
  { symbol: "COFFEE", name: "Caffè Arabica", category: "Alimentari", price: 284.10, change: 2.85, high: 288.5, low: 278.0, vol: "9.1B" },
  { symbol: "SUGAR", name: "Zucchero Grezzo", category: "Alimentari", price: 21.65, change: -0.80, high: 22.10, low: 21.40, vol: "5.3B" },
  { symbol: "SOYBEAN", name: "Soia Mercantile", category: "Alimentari", price: 1042.0, change: 0.40, high: 1050.0, low: 1035.0, vol: "8.9B" },

  // Materiali
  { symbol: "LITHIUM", name: "Litio Carbonato", category: "Materiali", price: 13500.0, change: 1.80, high: 13800.0, low: 13200.0, vol: "4.1B" },
  { symbol: "STEEL", name: "Acciaio Rebar", category: "Materiali", price: 512.0, change: -0.50, high: 518.0, low: 509.0, vol: "3.8B" },
  { symbol: "SILICON", name: "Silicio Policristallino", category: "Materiali", price: 14.50, change: 0.30, high: 14.80, low: 14.20, vol: "2.2B" },

  // Azioni Mondiali
  { symbol: "AAPL", name: "Apple Inc.", category: "Azioni", price: 227.90, change: -0.42, high: 230.1, low: 226.8, vol: "51.2B" },
  { symbol: "MSFT", name: "Microsoft Corp.", category: "Azioni", price: 417.24, change: 1.24, high: 419.5, low: 411.0, vol: "48.5B" },
  { symbol: "NVDA", name: "NVIDIA Corp.", category: "Azioni", price: 139.46, change: 3.12, high: 141.0, low: 134.8, vol: "78.4B" },
  { symbol: "TSLA", name: "Tesla Inc.", category: "Azioni", price: 248.15, change: -1.85, high: 255.0, low: 246.5, vol: "91.2B" },
  { symbol: "AMZN", name: "Amazon.com", category: "Azioni", price: 201.35, change: 0.88, high: 202.4, low: 198.9, vol: "34.5B" },
  { symbol: "GOOGL", name: "Alphabet Inc.", category: "Azioni", price: 172.56, change: 0.15, high: 174.0, low: 171.2, vol: "18.7B" },
  { symbol: "META", name: "Meta Platforms", category: "Azioni", price: 588.25, change: 2.05, high: 591.0, low: 575.0, vol: "22.3B" },
  { symbol: "ASML", name: "ASML Holding", category: "Azioni", price: 842.30, change: 1.82, high: 845.0, low: 825.5, vol: "14.2B" },
  { symbol: "Toyota", name: "Toyota Motor", category: "Azioni", price: 27.45, change: 1.45, high: 27.8, low: 27.0, vol: "28.9B" },
  { symbol: "Alibaba", name: "Alibaba Group", category: "Azioni", price: 112.45, change: -2.35, high: 116.0, low: 111.8, vol: "45.6B" },
  { symbol: "Samsung", name: "Samsung Elec", category: "Azioni", price: 714.50, change: 2.10, high: 718.0, low: 698.0, vol: "18.9B" },
  { symbol: "ENEL", name: "Enel SpA", category: "Azioni", price: 6.84, change: 0.52, high: 6.90, low: 6.80, vol: "9.4B" }
];

export const TradingView: React.FC<TradingViewProps> = ({ state, refreshState }) => {
  const [worldAssets, setWorldAssets] = useState<WorldAsset[]>(WORLD_WIDE_ASSETS);
  const [worldCategoryFilter, setWorldCategoryFilter] = useState<string>("Tutti");
  const [selectedSymbol, setSelectedSymbol] = useState("XAU-USD");
  const [searchQuery, setSearchQuery] = useState("");

  // Virtual Card & Crypto Processing State
  const [cardNumber, setCardNumber] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [depositAmount, setDepositAmount] = useState("2500");
  const [targetProfitLimit, setTargetProfitLimit] = useState("10000");
  const [isCryptoProcessingActive, setIsCryptoProcessingActive] = useState(false);
  const [cryptoCapital, setCryptoCapital] = useState(0);
  const [cryptoProfit, setCryptoProfit] = useState(0);

  // Live Activity Log & AI Acquisitions
  const [aiActiveActions, setAiActiveActions] = useState<Array<{ symbol: string; action: string; amount: number; time: string; pnl: number }>>([
    { symbol: "XAU-USD", action: "ACQUISTO AUTOMATICO ORO SPOT", amount: 2500, time: "16:05:12", pnl: 185.40 },
    { symbol: "BRENT", action: "ACQUISTO PETROLIO CRUDO", amount: 1800, time: "16:06:20", pnl: 92.10 },
    { symbol: "NVDA", action: "ACQUISTO AZIONI HIGH TECH", amount: 1200, time: "16:07:02", pnl: 45.50 }
  ]);
  const [logs, setLogs] = useState<string[]>([
    "16:07:50 [SYSTEM] Feed globale borsa, oro, petrolio, alimentari e materiali attivato.",
    "16:07:55 [AURORA AI] Margine d'errore allo 0,2% operativo su tutto il mercato mondiale."
  ]);

  const selectedAsset = worldAssets.find(a => a.symbol === selectedSymbol) || worldAssets[0];
  const chartCanvasRef = useRef<HTMLCanvasElement>(null);

  // Real-time market tick for EVERY global asset & Crypto AI Bot processing loop
  useEffect(() => {
    const interval = setInterval(() => {
      setWorldAssets(prev => prev.map(asset => {
        const volatility = asset.category === "Metalli & Oro" ? 0.0012 : asset.category === "Energia & Petrolio" ? 0.0025 : 0.0015;
        const delta = (Math.random() - 0.48) * asset.price * volatility;
        const newPrice = Math.max(0.1, asset.price + delta);
        const newChange = asset.change + (Math.random() - 0.5) * 0.08;
        return {
          ...asset,
          price: Number(newPrice.toFixed(2)),
          change: Number(newChange.toFixed(2)),
          high: Math.max(asset.high, newPrice),
          low: Math.min(asset.low, newPrice)
        };
      }));

      if (isCryptoProcessingActive && cryptoCapital > 0) {
        const targetProfit = parseFloat(targetProfitLimit) || 10000;
        const increment = Number((cryptoCapital * 0.0015 * (Math.random() * 1.8)).toFixed(2));
        setCryptoProfit(prev => {
          const nextVal = prev + increment;
          if (nextVal >= targetProfit) {
            setIsCryptoProcessingActive(false);
          }
          return nextVal;
        });

        if (Math.random() > 0.5) {
          const randAst = worldAssets[Math.floor(Math.random() * worldAssets.length)];
          setAiActiveActions(prev => [
            {
              symbol: randAst.symbol,
              action: `ARBITRAGGIO AUTOMATICO • ${randAst.category.toUpperCase()}`,
              amount: Math.floor(300 + Math.random() * 900),
              time: new Date().toLocaleTimeString('it-IT'),
              pnl: Number((Math.random() * 95).toFixed(2))
            },
            ...prev.slice(0, 20)
          ]);
        }
      }

    }, 1500);

    return () => clearInterval(interval);
  }, [isCryptoProcessingActive, cryptoCapital, targetProfitLimit, worldAssets]);

  // Render Large High-Precision Chart with Thin Lines & Price Tickers
  useEffect(() => {
    const canvas = chartCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#1a1a24';
    ctx.lineWidth = 0.5;
    const rows = 8;
    const cols = 12;

    for (let i = 0; i < rows; i++) {
      const y = (i / (rows - 1)) * (height - 50) + 25;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    for (let i = 0; i < cols; i++) {
      const x = (i / (cols - 1)) * width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height - 30);
      ctx.stroke();
    }

    const count = 75;
    let currentVal = selectedAsset.price * 0.98;
    const points = [];
    for (let i = 0; i < count; i++) {
      currentVal += (Math.sin(i * 0.25) * 2 + (Math.random() - 0.48) * 1.5);
      points.push(currentVal);
    }
    points[points.length - 1] = selectedAsset.price;

    const minP = Math.min(...points) * 0.998;
    const maxP = Math.max(...points) * 1.002;
    const span = maxP - minP || 1;

    ctx.strokeStyle = selectedAsset.change >= 0 ? '#00ff88' : '#ff3344';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    points.forEach((p, idx) => {
      const x = (idx / (count - 1)) * (width - 60) + 30;
      const y = (height - 50) - ((p - minP) / span) * (height - 70) + 15;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    ctx.fillStyle = '#6a6a7a';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillText(`TOP HIGH: ${maxP.toFixed(2)}`, 15, 18);
    ctx.fillText(`BOTTOM LOW: ${minP.toFixed(2)}`, 15, height - 10);
    ctx.fillText(`GLOBAL ASSET: ${selectedAsset.symbol} (${selectedAsset.name})`, width - 260, 18);

  }, [selectedAsset]);

  const handleProcessCrypto = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(depositAmount);
    if (!amount || amount <= 0) {
      alert("Inserisci un importo valido.");
      return;
    }
    if (!cardNumber || cardNumber.length < 12) {
      alert("Inserisci una carta virtuale valida.");
      return;
    }

    setCryptoCapital(amount);
    setCryptoProfit(0);
    setIsCryptoProcessingActive(true);
    setLogs(prev => [
      `[CRIPTO GATEWAY] Deposito di € ${amount.toFixed(2)} accreditato. IA Aurora avviata su azioni, oro, petrolio e materie prime.`,
      ...prev
    ]);
  };

  const filteredWorldAssets = worldAssets.filter(a => {
    if (worldCategoryFilter !== "Tutti" && a.category !== worldCategoryFilter) return false;
    if (searchQuery.trim() && !a.symbol.toLowerCase().includes(searchQuery.toLowerCase()) && !a.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Globe className="w-3.5 h-3.5 text-[#00ff88]" /> Mercato Mondiale Totale in Tempo Reale
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Aurora Trading • <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00ff88] to-cyan-400">Piazza Finanziaria Globale</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Azioni quotate, Oro, Argento, Materie Prime, Beni Alimentari, Carburanti e Petrolio. L'IA gestisce in automatico il capitale con un margine d'errore dello <strong className="text-[#00ff88]">0,2%</strong>.
            </p>
          </div>

          <div className="bg-slate-950/90 border border-[#00ff88]/30 px-6 py-4 rounded-2xl shadow-xl text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Capitale in Crescita AI</div>
            <div className="text-2xl font-extrabold font-mono text-[#00ff88] mt-1">
              € {(cryptoCapital + cryptoProfit).toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10px] text-cyan-400 font-mono mt-0.5">
              Profitto: +€ {cryptoProfit.toLocaleString('it-IT', { minimumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Virtual Card Deposit & Crypto Processing Controls */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-mono">Elabora Criptovalute & Fondi</h3>
              <p className="text-[11px] text-slate-400">Deposito carta virtuale per trading IA globale</p>
            </div>
          </div>

          <form onSubmit={handleProcessCrypto} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-mono text-slate-300">Numero Carta Virtuale</label>
              <input
                type="text"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                placeholder="4532 •••• •••• 8892"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-slate-300">Scadenza</label>
                <input
                  type="text"
                  value={cardExpiry}
                  onChange={(e) => setCardExpiry(e.target.value)}
                  placeholder="MM/AA"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-slate-300">CVV</label>
                <input
                  type="password"
                  maxLength={4}
                  value={cardCvv}
                  onChange={(e) => setCardCvv(e.target.value)}
                  placeholder="123"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-mono text-slate-300">Intestatario Carta</label>
              <input
                type="text"
                value={cardHolder}
                onChange={(e) => setCardHolder(e.target.value)}
                placeholder="Nome Titolare"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-slate-300">Capitale Iniziale (€)</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="2500"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-slate-300">Obiettivo Profitto (€)</label>
                <input
                  type="number"
                  value={targetProfitLimit}
                  onChange={(e) => setTargetProfitLimit(e.target.value)}
                  placeholder="10000"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-cyan-600 text-slate-950 font-bold font-mono text-xs shadow-lg shadow-emerald-500/20 hover:from-emerald-400 hover:to-cyan-500 transition-all flex items-center justify-center gap-2"
            >
              <Wallet className="w-4 h-4" />
              Elabora Criptovalute & Avvia IA
            </button>
          </form>

          {isCryptoProcessingActive && (
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center justify-between">
              <span>● IA in esecuzione automatica globale</span>
              <button 
                onClick={() => setIsCryptoProcessingActive(false)}
                className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30 text-[10px]"
              >
                Pausa
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Large Advanced Chart & Live AI Acquired Stocks Monitor */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Large Professional Chart Box */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                  <BarChart2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white font-mono">{selectedAsset.symbol}</h3>
                    <span className="text-xs text-slate-400">({selectedAsset.name})</span>
                  </div>
                  <p className="text-xs text-slate-400 font-mono">{selectedAsset.category} • Ultimo: € {selectedAsset.price.toFixed(2)}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 font-mono">
                <span className={`text-sm font-bold ${selectedAsset.change >= 0 ? 'text-[#00ff88]' : 'text-[#ff3344]'}`}>
                  {selectedAsset.change >= 0 ? '+' : ''}{selectedAsset.change}%
                </span>
              </div>
            </div>

            {/* Large Canvas Chart */}
            <div className="relative h-72 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-inner">
              <canvas ref={chartCanvasRef} className="w-full h-full block" style={{ width: '100%', height: '100%' }} />
            </div>

            {/* Asset Selector Row */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {worldAssets.slice(0, 15).map(m => (
                <button
                  key={m.symbol}
                  onClick={() => setSelectedSymbol(m.symbol)}
                  className={`px-3 py-1.5 rounded-xl font-mono text-xs border whitespace-nowrap transition-all ${
                    selectedSymbol === m.symbol 
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400' 
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {m.symbol} <span className={m.change >= 0 ? 'text-[#00ff88] ml-1' : 'text-[#ff3344] ml-1'}>{m.change >= 0 ? '+' : ''}{m.change}%</span>
                </button>
              ))}
            </div>
          </div>

          {/* Live AI Acquired Stocks & Capital Growth Monitor Box */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
                  <Cpu className="w-5 h-5 animate-spin" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-mono">Monitoraggio Attività IA & Operazioni Globali</h3>
                  <p className="text-[11px] text-slate-400">Azioni, oro, petrolio e materie prime in carico (margine errore 0.2%)</p>
                </div>
              </div>
              <span className="text-xs font-mono text-[#00ff88] bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                AI BOT ATTIVO
              </span>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {aiActiveActions.map((act, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/70 border border-slate-800 font-mono text-xs">
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-1 rounded bg-cyan-500/10 text-cyan-400 text-[11px] font-bold">
                      {act.symbol}
                    </span>
                    <div>
                      <div className="text-white font-medium">{act.action}</div>
                      <span className="text-[10px] text-slate-400">Capitale allocato: € {act.amount} • {act.time}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400">P&L Operazione</div>
                    <div className="text-[#00ff88] font-bold">
                      +€ {act.pnl.toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* ENORMOUS WORLDWIDE MARKET TICKER & LIVE GRID (Bottom Enormous Panel) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-bold text-white font-mono flex items-center gap-2">
              <Globe className="w-5 h-5 text-[#00ff88]" /> Enorme Grafico & Feed del Mercato Mondiale in Tempo Reale
            </h3>
            <p className="text-xs text-slate-400">
              Tutti gli asset mondiali aggiornati istantaneamente: Azioni, Oro, Argento, Materie Prime, Beni Alimentari, Carburanti e Petrolio.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {["Tutti", "Azioni", "Metalli & Oro", "Energia & Petrolio", "Alimentari", "Materiali"].map(cat => (
              <button
                key={cat}
                onClick={() => setWorldCategoryFilter(cat)}
                className={`px-3 py-1.5 rounded-xl font-mono text-xs transition-all ${
                  worldCategoryFilter === cat 
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow' 
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Search filter for global assets */}
        <div className="w-full">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cerca qualsiasi asset nel mercato mondiale (es. XAU-USD, Brent, Grano, Apple, Rame)..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Enormous Live Grid of All World Assets */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 max-h-[500px] overflow-y-auto pr-1">
          {filteredWorldAssets.map(asset => (
            <div
              key={asset.symbol}
              onClick={() => setSelectedSymbol(asset.symbol)}
              className={`p-3.5 rounded-2xl cursor-pointer border transition-all flex flex-col justify-between ${
                selectedSymbol === asset.symbol
                  ? 'bg-slate-800 border-cyan-400 shadow-lg'
                  : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-white font-mono text-xs">{asset.symbol}</span>
                <span className="text-[9px] font-mono text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded">
                  {asset.category}
                </span>
              </div>

              <div className="text-[11px] text-slate-300 truncate mb-3" title={asset.name}>
                {asset.name}
              </div>

              <div className="flex items-end justify-between font-mono">
                <div>
                  <div className="text-[10px] text-slate-500">Ultimo</div>
                  <div className="text-sm font-extrabold text-white">€ {asset.price.toLocaleString('it-IT', { minimumFractionDigits: 2 })}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-500">Var %</div>
                  <div className={`text-xs font-bold ${asset.change >= 0 ? 'text-[#00ff88]' : 'text-[#ff3344]'}`}>
                    {asset.change >= 0 ? '+' : ''}{asset.change}%
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
