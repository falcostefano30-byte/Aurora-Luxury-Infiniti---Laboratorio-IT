import React, { useState } from 'react';
import { AuroraState, TransactionItem } from '../types';
import { CreditCard, DollarSign, Send, ShieldCheck, CheckCircle2, History, AlertCircle, ArrowUpRight, Building2, Globe, ExternalLink } from 'lucide-react';

interface WalletViewProps {
  state: AuroraState;
  onTransferCompleted: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ state, onTransferCompleted }) => {
  const [amount, setAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cause, setCause] = useState('');
  const [bankName, setBankName] = useState('Intesa Sanpaolo');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [lastTransferData, setLastTransferData] = useState<{ amount: number; bank: string; portalUrl: string } | null>(null);

  // Comprehensive list of banking circuits and institutions with official real bank URLs
  const bankCircuits = [
    { name: 'Intesa Sanpaolo', type: 'Banca Tradizionale Italiana', code: 'ISP-IT', speed: 'Istantaneo SEPA', url: 'https://www.intesasanpaolo.com' },
    { name: 'UniCredit', type: 'Banca Internazionale', code: 'UNI-EU', speed: '1-2 Giorni Lavorativi', url: 'https://www.unicredit.it' },
    { name: 'Banco BPM', type: 'Banca Nazionale', code: 'BPM-IT', speed: 'Standard SEPA', url: 'https://www.bancobpm.it' },
    { name: 'Monte dei Paschi di Siena (MPS)', type: 'Banca Storica Italiana', code: 'MPS-IT', speed: 'Standard SEPA', url: 'https://www.mps.it' },
    { name: 'BPER Banca', type: 'Gruppo Bancario', code: 'BPER-IT', speed: 'Standard SEPA', url: 'https://www.bper.it' },
    { name: 'Fineco Bank', type: 'Banca Online & Trading', code: 'FIN-IT', speed: 'Istantaneo', url: 'https://www.fineco.it' },
    { name: 'Poste Italiane / BancoPosta', type: 'Servizi Postali & Conto', code: 'PST-IT', speed: '1-2 Giorni', url: 'https://www.poste.it' },
    { name: 'Revolut', type: 'Neobanca Internazionale', code: 'REV-GB', speed: 'Immediato', url: 'https://www.revolut.com' },
    { name: 'N26', type: 'Mobile Bank Europea', code: 'N26-DE', speed: 'Immediato', url: 'https://n26.com' },
    { name: 'Wise (TransferWise)', type: 'Circuito Trasferimenti Esteri', code: 'WISE-INT', speed: 'Istantaneo', url: 'https://wise.com' },
    { name: 'PayPal Secure', type: 'Portafoglio Elettronico', code: 'PP-GL', speed: 'Immediato', url: 'https://www.paypal.com' },
    { name: 'Visa / Mastercard', type: 'Circuiti Internazionali di Pagamento', code: 'CC-GLOBAL', speed: 'Real-time', url: 'https://www.visa.it' },
    { name: 'Coinbase / Crypto Gateway', type: 'Exchange & Wallet Criptovalute', code: 'CB-CRYPTO', speed: 'Immediato On-Chain', url: 'https://www.coinbase.com' },
    { name: 'Stripe Payment Gateway', type: 'Piattaforma Pagamenti Online', code: 'ST-GATEWAY', speed: 'Istantaneo', url: 'https://stripe.com' },
    { name: 'IBAN SEPA Bancario (Generico)', type: 'Circuito Unico Europeo Bonifici', code: 'SEPA-EU', speed: '1 Giorno Lavorativo', url: 'https://www.ecb.europa.eu' }
  ];

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);
    setLastTransferData(null);

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      setMessage({ type: 'error', text: 'Inserisci un importo valido.' });
      return;
    }

    if (!cardNumber || cardNumber.length < 8) {
      setMessage({ type: 'error', text: 'Inserisci un numero di conto, IBAN o carta valido.' });
      return;
    }

    if (!cardHolder) {
      setMessage({ type: 'error', text: 'Inserisci il nome del titolare del conto/carta.' });
      return;
    }

    const matchedBank = bankCircuits.find(b => b.name === bankName) || bankCircuits[0];

    setLoading(true);
    try {
      const response = await fetch('/api/aurora/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: numAmount,
          cardNumber,
          cardHolder,
          cause: cause || 'Bonifico guadagni IT Aurora Luxury Infiniti',
          bankName
        })
      });
      const data = await response.json();

      if (response.ok && data.success) {
        setMessage({
          type: 'success',
          text: `Bonifico di € ${numAmount.toFixed(2)} registrato con successo. Aurora ti sta reindirizzando al portale ufficiale della banca (${bankName}) per completare l'erogazione.`
        });
        setLastTransferData({
          amount: numAmount,
          bank: bankName,
          portalUrl: matchedBank.url
        });
        setAmount('');
        setCardNumber('');
        setCardHolder('');
        setCause('');
        onTransferCompleted();
      } else {
        setMessage({ type: 'error', text: data.error || 'Errore durante il trasferimento.' });
      }
    } catch (err) {
      console.error(err);
      setMessage({ type: 'error', text: 'Errore di connessione con il gateway bancario.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono uppercase tracking-widest">
              <CreditCard className="w-3.5 h-3.5" /> Gestione Conto & Trasferimenti
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Il Conto di <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">Aurora Luxury Infiniti</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Gestisci i compensi accumulati da Aurora tramite i micro-lavori di rete e trasferisci fondi in tempo reale. Dopo la compilazione dei dati, verrai reindirizzato direttamente al sito ufficiale della banca scelta per completare l'erogazione con la cifra esatta.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-emerald-500/30 px-6 py-4 rounded-2xl shadow-xl text-center">
            <div className="text-xs text-slate-400 uppercase font-mono">Disponibile sul Conto</div>
            <div className="text-2xl lg:text-3xl font-extrabold font-mono text-emerald-300 mt-1">
              € {state.balance.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Transfer Form */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Trasferimento Verso Conto o Carta</h3>
              <p className="text-xs text-slate-400">Seleziona la banca, inserisci i dati e accedi al portale ufficiale di erogazione</p>
            </div>
          </div>

          {message && (
            <div className={`p-4 rounded-2xl text-xs font-mono flex flex-col gap-3 border ${
              message.type === 'success'
                ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-300'
                : 'bg-red-950/60 border-red-500/30 text-red-300'
            }`}>
              <div className="flex items-start gap-2">
                {message.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />}
                <span>{message.text}</span>
              </div>

              {lastTransferData && (
                <div className="mt-2 pt-3 border-t border-emerald-500/20 flex flex-col sm:flex-row items-center justify-between gap-3 bg-emerald-900/40 p-3 rounded-xl">
                  <div>
                    <div className="text-[10px] text-emerald-200 uppercase font-bold">Importo Pronto per Erogazione: € {lastTransferData.amount.toFixed(2)}</div>
                    <div className="text-xs text-white font-mono">Banca: {lastTransferData.bank}</div>
                  </div>
                  <a
                    href={lastTransferData.portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition-all"
                  >
                    Vai al Sito Ufficiale della Banca <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          )}

          <form onSubmit={handleTransfer} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-slate-300">Importo da trasferire (€)</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3 text-slate-400 font-mono">€</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    max={state.balance}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 pl-8 text-white font-mono text-sm focus:outline-none focus:border-emerald-500 transition-all"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono text-slate-300">Circuito / Banca di Destinazione</label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 transition-all"
                >
                  {bankCircuits.map((b, i) => (
                    <option key={i} value={b.name}>{b.name} ({b.type})</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-slate-300">Numero Conto, IBAN o Carta</label>
              <input
                type="text"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                placeholder="IT60 X 03032 03200 1000000XXXX o 4000..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-emerald-500 transition-all"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-slate-300">Intestatario della Carta / Conto</label>
              <input
                type="text"
                value={cardHolder}
                onChange={(e) => setCardHolder(e.target.value)}
                placeholder="Nome e Cognome del Titolare"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-slate-300">Causale del Trasferimento</label>
              <input
                type="text"
                value={cause}
                onChange={(e) => setCause(e.target.value)}
                placeholder="es. Liquidazione provvigioni IT Aurora"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={loading || state.balance <= 0}
              className={`w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-cyan-600 text-white font-bold text-sm shadow-lg shadow-emerald-500/20 hover:from-emerald-400 hover:to-cyan-500 transition-all flex items-center justify-center gap-2 ${
                loading || state.balance <= 0 ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {loading ? (
                <span>Elaborazione e reindirizzamento banca...</span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Procedi al Portale Ufficiale della Banca
                </>
              )}
            </button>
          </form>
        </div>

        {/* Legend & Circuits Directory */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Leggenda Circuiti & Banche Supportate</h3>
              <p className="text-xs text-slate-400">Elenco completo di tutte le banche abilitate al reindirizzamento ufficiale</p>
            </div>
          </div>

          <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
            {bankCircuits.map((bank, index) => (
              <div key={index} className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-mono text-xs font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{bank.name}</h4>
                    <p className="text-[11px] text-slate-400">{bank.type}</p>
                  </div>
                </div>
                <div className="text-right flex items-center gap-2">
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2 py-1 rounded-lg">
                    {bank.speed}
                  </span>
                  <a href={bank.url} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white" title="Visita sito ufficiale">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Transaction History Row */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Storico Transazioni & Bonifici</h3>
              <p className="text-xs text-slate-400">Registro dei trasferimenti effettuati verso conti esterni</p>
            </div>
          </div>
        </div>

        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          {state.transactions.map((tx: TransactionItem) => (
            <div key={tx.id} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-mono text-cyan-400 font-semibold">{tx.id}</span>
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                    {tx.status}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white">{tx.recipientName}</h4>
                <p className="text-xs text-slate-400 font-mono">{tx.recipientCard}</p>
                <p className="text-xs text-slate-300 italic mt-0.5">"{tx.reference}"</p>
              </div>
              <div className="text-right">
                <div className="text-base font-bold font-mono text-emerald-300">
                  -€ {tx.amount.toFixed(2)}
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {new Date(tx.timestamp).toLocaleDateString('it-IT')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
