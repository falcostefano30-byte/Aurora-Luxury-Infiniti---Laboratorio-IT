import React, { useState, useEffect, useRef } from 'react';
import { AuroraState, TaskItem } from '../types';
import { Zap, Search, CheckCircle2, Clock, DollarSign, Sparkles, Play, Pause, Cpu, ExternalLink, RefreshCw, Terminal, ArrowRight, ShieldCheck } from 'lucide-react';

interface WorkViewProps {
  state: AuroraState;
  onTasksUpdated: () => void;
}

export const WorkView: React.FC<WorkViewProps> = ({ state, onTasksUpdated }) => {
  const [isAutoRunning, setIsAutoRunning] = useState(false);
  const [liveLogs, setLiveLogs] = useState<Array<{ time: string; text: string; task?: TaskItem }>>([]);
  const [selectedTaskCode, setSelectedTaskCode] = useState('');
  const [accessResult, setAccessResult] = useState<{ url: string; title: string } | null>(null);
  const [isScanningOnce, setIsScanningOnce] = useState(false);

  // Reference for auto-running interval
  const loopRef = useRef<any>(null);

  // Function to execute a scan & work cycle
  const executeScanCycle = async () => {
    const timestamp = new Date().toLocaleTimeString('it-IT');
    setLiveLogs(prev => [{ time: timestamp, text: '🔍 Aurora sta scansionando i nodi della rete globale per nuovi micro-incarichi...' }, ...prev.slice(0, 19)]);

    try {
      const response = await fetch('/api/aurora/scan-tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();

      if (data.success && data.newTasks && data.newTasks.length > 0) {
        const newTask = data.newTasks[0];
        setLiveLogs(prev => [
          { 
            time: new Date().toLocaleTimeString('it-IT'), 
            text: `✅ Lavoro completato con successo: [${newTask.id}] "${newTask.title}" (${newTask.category}) - Committente: ${newTask.client} | Compenso: € +${newTask.reward.toFixed(2)}`,
            task: newTask
          },
          ...prev.slice(0, 19)
        ]);
        onTasksUpdated();
      }
    } catch (err) {
      console.error(err);
      setLiveLogs(prev => [{ time: new Date().toLocaleTimeString('it-IT'), text: '❌ Errore temporaneo nella connessione al gateway di scansione.' }, ...prev.slice(0, 19)]);
    }
  };

  // Toggle Auto Run loop
  const toggleAutoLoop = () => {
    if (isAutoRunning) {
      // Stop
      setIsAutoRunning(false);
      if (loopRef.current) {
        clearInterval(loopRef.current);
        loopRef.current = null;
      }
      setLiveLogs(prev => [{ time: new Date().toLocaleTimeString('it-IT'), text: '⏹️ Meccanismo di automazione fermato dall\'utente.' }, ...prev.slice(0, 19)]);
    } else {
      // Start
      setIsAutoRunning(true);
      setLiveLogs(prev => [{ time: new Date().toLocaleTimeString('it-IT'), text: '🚀 Avvio meccanismo di scansione automatica continua (Loop 24/7 attivo)...' }, ...prev.slice(0, 19)]);
      executeScanCycle();
      loopRef.current = setInterval(() => {
        executeScanCycle();
      }, 5000); // Ogni 5 secondi esegue un nuovo ciclo di lavoro
    }
  };

  // Single manual scan
  const handleSingleScan = async () => {
    setIsScanningOnce(true);
    await executeScanCycle();
    setTimeout(() => setIsScanningOnce(false), 1000);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (loopRef.current) clearInterval(loopRef.current);
    };
  }, []);

  // Handle access code submission
  const handleAccessService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTaskCode.trim()) return;

    const matchedTask = state.tasks.find(t => t.id === selectedTaskCode.trim());
    const serviceUrl = `https://portal.aurora-luxury-infiniti.io/jobs/verify/${encodeURIComponent(selectedTaskCode.trim())}`;
    
    setAccessResult({
      url: serviceUrl,
      title: matchedTask ? matchedTask.title : `Incarico ID: ${selectedTaskCode.trim()}`
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-950 to-slate-900 border border-cyan-500/30 p-6 lg:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest">
              <Zap className="w-3.5 h-3.5" /> Motore di Lavoro Autonomo & Loop 24/7
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
              Lavoro di <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400">Aurora Luxury Infiniti</span>
            </h2>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Avvia la scansione e l'automazione continua. Il sistema individua micro-incarichi di rete, li svolge istantaneamente, accredita i compensi sul capitale del sito e registra ogni mansione nello storico in tempo reale.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={toggleAutoLoop}
              className={`flex items-center gap-3 px-6 py-3.5 rounded-2xl font-bold shadow-lg transition-all transform active:scale-95 ${
                isAutoRunning
                  ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-red-500/30 animate-pulse'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-cyan-500/25 hover:from-cyan-400 hover:to-blue-500'
              }`}
            >
              {isAutoRunning ? (
                <>
                  <Pause className="w-5 h-5 fill-current" />
                  Ferma Meccanismo (Automazione Attiva)
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  Avvia Scansione e Svolgi Lavoro (Loop)
                </>
              )}
            </button>

            <button
              onClick={handleSingleScan}
              disabled={isScanningOnce || isAutoRunning}
              className="flex items-center gap-2 px-4 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 disabled:opacity-40"
            >
              <RefreshCw className={`w-4 h-4 ${isScanningOnce ? 'animate-spin' : ''}`} />
              Esegui Singolo Task
            </button>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase font-mono">Incarichi Completati</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">{state.completedTasksCount}</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase font-mono">Capitale / Guadagni Totali</div>
            <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">
              € {state.balance.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase font-mono">Stato Automazione</div>
            <div className={`text-sm font-bold font-mono mt-1 ${isAutoRunning ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`}>
              {isAutoRunning ? 'LOOP 24/7 ATTIVO' : 'IN PAUSA'}
            </div>
          </div>
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${isAutoRunning ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
            <Cpu className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* LIVE FINSTERA: Tutti i lavori che sta facendo e completando in tempo reale */}
      <div className="bg-slate-900/90 border border-cyan-500/30 rounded-3xl p-6 lg:p-8 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Terminal className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Finestra Live • Monitoraggio Lavori in Corso</h3>
              <p className="text-xs text-slate-400">Flusso in tempo reale delle scansioni, analisi e completamento incarichi di Aurora</p>
            </div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${isAutoRunning ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'}`}>
            {isAutoRunning ? '🟢 ATTIVO IN STREAMING' : '⏸️ IN ATTESA DI AVVIO'}
          </span>
        </div>

        {/* Terminal Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 h-56 overflow-y-auto font-mono text-xs space-y-2">
          {liveLogs.length === 0 ? (
            <div className="text-slate-500 italic text-center py-16">
              Nessuna attività registrata. Clicca su "Avvia Scansione e Svolgi Lavoro" per iniziare il loop automatico.
            </div>
          ) : (
            liveLogs.map((log, idx) => (
              <div key={idx} className="flex items-start gap-3 text-slate-300 border-b border-slate-900 pb-1.5">
                <span className="text-cyan-500 shrink-0">[{log.time}]</span>
                <span className="flex-1">{log.text}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Riquadro Inserimento Codice per Accesso al Servizio Ufficiale */}
      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Accesso al Servizio Ufficiale tramite Codice Incarico</h3>
            <p className="text-xs text-slate-400">Inserisci il codice del lavoro completato per aprire il portale partner e la verifica ufficiale</p>
          </div>
        </div>

        <form onSubmit={handleAccessService} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="md:col-span-2 space-y-1.5">
            <label className="text-xs font-mono text-slate-300">Seleziona o Inserisci Codice Incarico (ID Task)</label>
            <select
              value={selectedTaskCode}
              onChange={(e) => setSelectedTaskCode(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
            >
              <option value="">-- Seleziona un task completato dall'elenco --</option>
              {state.tasks.map((task) => (
                <option key={task.id} value={task.id}>
                  {task.id} • {task.title} (€ {task.reward.toFixed(2)})
                </option>
              ))}
            </select>
          </div>

          <div>
            <button
              type="submit"
              disabled={!selectedTaskCode}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold py-3 px-6 rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              Accedi al Servizio <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        {accessResult && (
          <div className="p-4 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono text-indigo-300 uppercase tracking-widest">Verifica Portale Ufficiale</span>
              <h4 className="text-sm font-bold text-white">{accessResult.title}</h4>
              <p className="text-xs font-mono text-cyan-400 mt-0.5">{accessResult.url}</p>
            </div>
            <a
              href={accessResult.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shrink-0 shadow-md"
            >
              Apri Portale Esterno <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </div>

      {/* Registro Mansioni Effettuate & Storico */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Registro Mansioni & Storico Incarichi</h3>
              <p className="text-xs text-slate-400">Dettaglio completo di tutte le mansioni svolte e accreditate sul capitale del sito</p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400 bg-slate-800 px-3 py-1 rounded-full">
            {state.tasks.length} mansioni registrate
          </span>
        </div>

        <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
          {state.tasks.map((task: TaskItem) => (
            <div 
              key={task.id}
              className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-cyan-500/40 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 uppercase font-mono">
                    {task.category}
                  </span>
                  <span className="text-xs font-mono text-indigo-300">
                    ID: {task.id}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    Committente: <strong className="text-slate-200">{task.client}</strong>
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white">{task.title}</h4>
                <p className="text-xs text-slate-400">{task.details}</p>
                <div className="flex items-center gap-4 text-[11px] text-slate-400 font-mono pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" /> Svolto in {task.duration}
                  </span>
                  <span>• {new Date(task.timestamp).toLocaleTimeString('it-IT')}</span>
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="text-lg font-bold font-mono text-emerald-400">
                  + € {task.reward.toFixed(2)}
                </div>
                <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  accreditato in capitale
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
