export interface TaskItem {
  id: string;
  title: string;
  category: string;
  client: string;
  reward: number;
  status: string;
  duration: string;
  timestamp: string;
  details: string;
}

export interface TransactionItem {
  id: string;
  amount: number;
  recipientCard: string;
  recipientName: string;
  reference: string;
  status: string;
  timestamp: string;
}

export interface AuroraState {
  balance: number;
  status: string;
  activeThreads: number;
  completedTasksCount: number;
  cpuUsage: number;
  quantumCoreTemp: string;
  earningsToday: number;
  tasks: TaskItem[];
  transactions: TransactionItem[];
}
